// const { Sequelize } = require('sequelize');

// module.exports = new Sequelize('h5', 'root', 'root123', {
//     host: 'localhost',
//     dialect:'mysql',

//     // 处理 userId = > user_id
//     define:{
//        underscored:true
//     },
//     timezone:'+08:00'
//   });
